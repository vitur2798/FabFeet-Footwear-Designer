package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.NewCustomer;
import com.fab.dao.DBOperations;

@WebServlet("/NewCustomerServlet")
public class NewCustomerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String first_name=request.getParameter("first_name");
		String last_name=request.getParameter("last_name");
		String user_name=request.getParameter("user_name");
		String register_number=request.getParameter("register_number");
		String email=request.getParameter("email");
		String phone_number=request.getParameter("phone_number");
		String pwd=request.getParameter("pwd");
		String address=request.getParameter("address");
		
		NewCustomer newcustomer=new NewCustomer();
		newcustomer.setFirst_name(first_name);
		newcustomer.setLast_name(last_name);
		newcustomer.setUser_name(user_name);
		newcustomer.setRegister_number(register_number);
		newcustomer.setPhone_number(phone_number);
		newcustomer.setPwd(pwd);
		newcustomer.setAddress(address);
		newcustomer.setEmail(email);
		
		DBOperations dboperations=new DBOperations();
		dboperations.newcustomer_insert(newcustomer);
		
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("CustomerLogin.html");
		rd.include(request, response);
	}

}

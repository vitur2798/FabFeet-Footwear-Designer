package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.CustomerLogin;
import com.fab.bean.ManagerLogin;
import com.fab.dao.DBOperations;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String admin_username = request.getParameter("admin_username");
		String admin_password = request.getParameter("admin_password");

		RequestDispatcher rd;
		if (admin_username.equals("gupta@gmail.com") && admin_password.equals("1234")) {
			rd = request.getRequestDispatcher("Admin.html");
			rd.include(request, response);
		} else {
			rd = request.getRequestDispatcher("Error.html");
			rd.include(request, response);
		}
	}
}

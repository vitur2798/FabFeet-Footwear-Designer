package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.Billing;
import com.fab.dao.DBOperations;

@WebServlet("/BillingServlet")
public class BillingServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String product_id=request.getParameter("product_id");
		String product_name=request.getParameter("product_name");
		String customer_username=request.getParameter("customer_username");
		String quantity=request.getParameter("quantity");
		String cost=request.getParameter("cost");
		
		Billing billing=new Billing();
		billing.setProduct_id(product_id);
		billing.setProduct_name(product_name);
		billing.setCustomer_username(customer_username);
		billing.setQuantity(quantity);
		billing.setCost(cost);
		DBOperations dboperations=new DBOperations();
		dboperations.billing_insert(billing);
		List<Billing> result=dboperations.display(); 
		for(Billing temp:result) 
			out.println("<html><table><tr><td>+"+temp+"</td></tr></table></html>");

	}

}

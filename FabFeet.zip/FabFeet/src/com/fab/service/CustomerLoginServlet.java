package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.CustomerLogin;
import com.fab.dao.DBOperations;


@WebServlet("/CustomerLoginServlet")
public class CustomerLoginServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		CustomerLogin customerlogin=new CustomerLogin();
		String customer_username=request.getParameter("customer_username");
		String customer_password=request.getParameter("customer_password");
		customerlogin.setCustomer_username(customer_username);
		customerlogin.setCustomer_password(customer_password);
		
		
		DBOperations dboperations=new DBOperations();
		dboperations.customerlogin_insert(customerlogin);
		
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("Customer.html");
		rd.include(request, response);
	}

}

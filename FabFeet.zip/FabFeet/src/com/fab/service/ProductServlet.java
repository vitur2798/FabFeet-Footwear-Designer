package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.Product;
import com.fab.dao.DBOperations;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String product_id=request.getParameter("product_id");
		String product_name=request.getParameter("product_name");
		String quantity=request.getParameter("quantity");
		
		Product product=new Product();
		product.setProduct_id(product_id);
		product.setProduct_name(product_name);
		product.setQuantity(quantity);
		
		DBOperations dboperations=new DBOperations();
		dboperations.product_insert(product);
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("Manager.html");
		rd.include(request, response);
	}

}

package com.fab.bean;

import java.util.ArrayList;

public class Product {
	private String product_id;
	private String product_name;
	private String quantity;
	

	public Product() {
	}

	public String getProduct_id() {
		return product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public String getQuantity() {
		return quantity;
	}

	

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	

}

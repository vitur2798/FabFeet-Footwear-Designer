package com.fab.bean;

public class Billing {
	private String product_id;
	private String product_name;
	private String customer_username;
	private String quantity;
	private String cost;

	public Billing() {
		// TODO Auto-generated constructor stub
	}

	public String getProduct_id() {
		return product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public String getCustomer_username() {
		return customer_username;
	}

	public String getQuantity() {
		return quantity;
	}

	public String getCost() {
		return cost;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public void setCustomer_username(String customer_username) {
		this.customer_username = customer_username;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Billing [product_id=" + product_id + ", product_name=" + product_name + ", customer_username="
				+ customer_username + ", quantity=" + quantity + ", cost=" + cost + "]";
	}
	

}

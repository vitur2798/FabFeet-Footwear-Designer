package com.fab.bean;

public class CustomerLogin {
	private String customer_username;
	private String customer_password;

	public CustomerLogin() {
		// TODO Auto-generated constructor stub
	}

	public String getCustomer_username() {
		return customer_username;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_username(String customer_username) {
		this.customer_username = customer_username;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	@Override
	public String toString() {
		return "CustomerLogin [customer_username=" + customer_username + ", customer_password=" + customer_password
				+ "]";
	}
	

}

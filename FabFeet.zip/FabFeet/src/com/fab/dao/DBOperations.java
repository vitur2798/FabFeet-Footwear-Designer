package com.fab.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.fab.bean.Billing;
import com.fab.bean.CustomerLogin;
import com.fab.bean.ManagerLogin;
import com.fab.bean.NewCustomer;
import com.fab.bean.Product;

public class DBOperations {
	SessionFactory sеssionFactory;
	Session session;
	Transaction tx;

	public DBOperations() {
		sеssionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}

	public void customerlogin_insert(CustomerLogin customerlogin) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(customerlogin);
			tx.commit();
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}
	
	public void product_insert(Product product) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(product);
			tx.commit();
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}
	
	public void newcustomer_insert(NewCustomer newcustomer) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(newcustomer);
			tx.commit();
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}

	public void managerlogin_insert(ManagerLogin managerlogin) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(managerlogin);
			tx.commit();
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}
	public void billing_insert(Billing billing) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(billing);
			tx.commit();
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}
	}
		
		public List<Billing> display() {   
			List<Billing> result=null;  
			session=sеssionFactory.openSession();  
			tx=session.beginTransaction();  
			try   {   
				Query query=session.createQuery("FROM Billing"); 
				result=query.list();  
				session.close(); 
				}   
			catch(Exception e)  
			{    result=null;  
			}   
			return result;
			} 

	
	
}
